﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using Park20.Backoffice.Core.Domain.Payment;
using Park20.Backoffice.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park20.Backoffice.Tests.Repositories
{
    [TestFixture]
    internal class InvoiceRepositoryTest
    {

    }
}
