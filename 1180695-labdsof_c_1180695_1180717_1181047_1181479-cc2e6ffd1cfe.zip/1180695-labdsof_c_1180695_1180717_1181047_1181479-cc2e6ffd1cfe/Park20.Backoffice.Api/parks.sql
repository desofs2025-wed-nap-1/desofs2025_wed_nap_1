CREATE TABLE [dbo].[Park] (
    [Id]           INT            IDENTITY (1, 1) NOT NULL,
    [NumberFloors] INT            NOT NULL,
    [ParkName]     NVARCHAR (255) NOT NULL,
    [Latitude]     FLOAT (53)     NOT NULL,
    [Longitude]    FLOAT (53)     NOT NULL,
    [OpeningTime]  DATETIME       NOT NULL,
    [ClosingTime]  DATETIME       NOT NULL,
    [IsActive]     BIT            NOT NULL,
    [NightFee]     FLOAT (53)     NOT NULL,
    [PriceTableId] INT            NOT NULL,
    CONSTRAINT [PK_Park] PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[ParkingSpot] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
    [Status] BIT NOT NULL,
    [FloorNumber] INT NOT NULL,
    [VehicleType] NVARCHAR (255) NOT NULL,
    [ParkId] INT NOT NULL,
    CONSTRAINT [PK_ParkingSpot] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ParkId] FOREIGN KEY ([ParkId]) REFERENCES [dbo].[Park] ([Id])
);

CREATE TABLE [dbo].[PriceTable] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
    [InitialDate] DATETIME NOT NULL,
    CONSTRAINT [PK_PriceTable] PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[LinePriceTable] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
    [PeriodId] INT NOT NULL,
	[PriceTableId] INT NOT NULL,
    CONSTRAINT [PK_LinePriceTable] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_PriceTableId] FOREIGN KEY ([PriceTableId]) REFERENCES [dbo].[PriceTable] ([Id])
);

CREATE TABLE [dbo].[Period] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
    [InitialTime] TIME NOT NULL,
    [FinalTime] TIME NOT NULL,
    CONSTRAINT [PK_Period] PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Fraction] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
    [Order] INT NOT NULL,
    [Minutes] TIME NOT NULL,
    [VehicleType] NVARCHAR (255) NOT NULL,
	[PeriodId] INT NOT NULL,
    CONSTRAINT [PK_Fraction] PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [FK_PeriodId] FOREIGN KEY ([PeriodId]) REFERENCES [dbo].[Period]([Id])
);


-- Mock data for Park table
INSERT INTO [dbo].[Park] ([NumberFloors], [ParkName], [Latitude], [Longitude], [OpeningTime], [ClosingTime], [IsActive], [NightFee], [PriceTableId])
VALUES (5, 'City Park', 41.1496, -8.6109, '2023-11-14T08:00:00', '2023-11-14T18:00:00', 1, 5.0, 1),
       (3, 'Central Park', 41.1492, -8.6115, '2023-11-14T09:00:00', '2023-11-14T17:00:00', 1, 3.5, 2);

-- Mock data for ParkingSpot table
INSERT INTO [dbo].[ParkingSpot] ([Status], [FloorNumber], [VehicleType], [ParkId])
VALUES 
    (1, 1, 'GPL', 1),
    (0, 2, 'Motorcycle', 1),
    (1, 1, 'Automobile', 2),
    (0, 2, 'Motorcycle', 2),
    (1, 3, 'Automobile', 2);

-- Mock data for PriceTable table
INSERT INTO [dbo].[PriceTable] ([InitialDate])
VALUES ('2023-11-14T00:00:00'),
       ('2023-11-14T00:00:00');

-- Mock data for LinePriceTable table
INSERT INTO [dbo].[LinePriceTable] ([PeriodId], [PriceTableId])
VALUES (1, 1),
       (2, 1),
       (3, 1),
       (1, 2),
       (2, 2),
       (3, 2);

-- Mock data for Period table
INSERT INTO [dbo].[Period] ([InitialTime], [FinalTime])
VALUES ('08:00:00', '12:00:00'),
       ('12:00:00', '16:00:00'),
       ('16:00:00', '20:00:00'),
       ('09:00:00', '12:00:00'),
       ('12:00:00', '15:00:00'),
       ('15:00:00', '18:00:00');

-- Mock data for Fraction table
INSERT INTO [dbo].[Fraction] ([Order], [Minutes], [VehicleType], [PeriodId])
VALUES (1, '00:15:00', 'Motorcycle', 1),
       (2, '00:30:00', 'Automobile', 1),
       (3, '00:45:00', 'GPL', 1),
       (4, '01:00:00', 'Electric', 1),
       (1, '00:20:00', 'Motorcycle', 2),
       (2, '00:40:00', 'Automobile', 2),
       (3, '01:00:00', 'GPL', 2),
       (4, '01:20:00', 'Electric', 2),
       (1, '00:10:00', 'Motorcycle', 3),
       (2, '00:20:00', 'Automobile', 3),
       (3, '00:30:00', 'GPL', 3),
       (4, '00:40:00', 'Electric', 3),
       (1, '00:15:00', 'Motorcycle', 4),
       (2, '00:30:00', 'Automobile', 4),
       (3, '00:45:00', 'GPL', 4),
       (4, '01:00:00', 'Electric', 4),
       (1, '00:10:00', 'Motorcycle', 5),
       (2, '00:20:00', 'Automobile', 5),
       (3, '00:30:00', 'GPL', 5),
       (4, '00:40:00', 'Electric', 5),
       (1, '00:15:00', 'Motorcycle', 6),
       (2, '00:30:00', 'Automobile', 6),
       (3, '00:45:00', 'GPL', 6);