﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park20.Backoffice.Core.Domain
{
    public enum VehicleType
    {
        Motocycle = 0,
        Automobile = 1,
        GPL = 2,
        Electric = 3,
    }
}
