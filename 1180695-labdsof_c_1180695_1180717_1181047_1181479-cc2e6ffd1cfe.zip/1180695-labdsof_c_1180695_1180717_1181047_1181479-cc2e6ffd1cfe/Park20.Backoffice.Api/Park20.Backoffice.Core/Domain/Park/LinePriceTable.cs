﻿namespace Park20.Backoffice.Core.Domain.Park
{
    public class LinePriceTable
    {
        public int LinePriceTableId { get; set; }
        public Period Period { get; set; }
    }
}
