﻿namespace Park20.Backoffice.Core.Dtos.Requests
{
    public class ParkCheckRequestDto
    {
        public string LicencePlate { get; set; }
        public string ParkName { get; set; }
    }
}
