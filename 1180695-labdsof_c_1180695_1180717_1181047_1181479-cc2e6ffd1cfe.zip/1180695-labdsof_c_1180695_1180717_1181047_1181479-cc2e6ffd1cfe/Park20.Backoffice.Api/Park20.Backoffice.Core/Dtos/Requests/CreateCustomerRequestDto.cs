﻿namespace Park20.Backoffice.Core.Dtos.Requests
{
    public record CreateCustomerRequestDto(string Name, string Password, string Email, string Username);
}
