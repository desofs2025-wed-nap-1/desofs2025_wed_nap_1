﻿namespace Park20.Backoffice.Core.Dtos.Requests
{
    public record GetParkVehicleRequestDto(string ParkName, string LicencePlate);
}
