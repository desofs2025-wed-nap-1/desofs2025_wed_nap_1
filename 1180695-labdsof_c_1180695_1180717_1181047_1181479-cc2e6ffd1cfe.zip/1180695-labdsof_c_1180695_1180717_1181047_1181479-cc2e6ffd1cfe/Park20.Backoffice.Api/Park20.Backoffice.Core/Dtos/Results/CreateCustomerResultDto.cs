﻿namespace Park20.Backoffice.Core.Dtos.Results
{
    public record CreateCustomerResultDto(string Name, string Email, string Username);
}
