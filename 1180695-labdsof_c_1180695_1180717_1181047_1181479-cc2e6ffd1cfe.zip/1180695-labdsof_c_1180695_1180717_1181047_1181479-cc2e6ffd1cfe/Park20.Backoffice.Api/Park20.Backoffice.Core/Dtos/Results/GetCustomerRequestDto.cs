﻿namespace Park20.Backoffice.Core.Dtos.Requests
{
    public record GetCustomerResultDto(string Name, string Email, string Username);
}
