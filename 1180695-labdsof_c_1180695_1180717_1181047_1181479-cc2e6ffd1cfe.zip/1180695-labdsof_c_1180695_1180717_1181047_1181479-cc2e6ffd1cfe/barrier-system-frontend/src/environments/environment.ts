export const environment = {
  production: false,
  signalRBaseUrl: 'http://localhost:5002',
};
