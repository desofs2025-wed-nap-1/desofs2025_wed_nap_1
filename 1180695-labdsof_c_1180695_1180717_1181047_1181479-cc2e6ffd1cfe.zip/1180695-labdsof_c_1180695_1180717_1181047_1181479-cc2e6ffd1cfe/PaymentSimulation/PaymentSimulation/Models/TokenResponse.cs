﻿namespace PaymentSimulation.Models
{
    public record TokenResponse(string Token);
}
