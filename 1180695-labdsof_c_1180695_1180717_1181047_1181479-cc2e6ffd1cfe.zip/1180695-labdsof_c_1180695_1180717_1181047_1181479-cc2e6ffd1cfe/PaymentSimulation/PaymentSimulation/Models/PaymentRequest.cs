﻿namespace PaymentSimulation.Models
{
    public class PaymentRequest
    {
        public string Token { get; set; }
        public decimal Amount { get; set; }
    }
}
