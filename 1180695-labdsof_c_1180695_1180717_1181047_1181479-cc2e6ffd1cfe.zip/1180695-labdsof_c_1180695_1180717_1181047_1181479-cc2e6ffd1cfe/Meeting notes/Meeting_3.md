## Meeting 3 ##

Q: Is there any legacy system that needs integration into our app or is the solution entirely new? 

R. The solution is entirely new.

Q: Are reservations accepted in the parking lots? 

R. Reservations are not accepted.

Q: In case of an emergency and the user cannot pay, what happens? 

R. Allow the user to exit the parking lot and create a debt alert in the app.

Q. Can an electric car park in a regular parking spot? 

R. Cars should park in the corresponding spots.

Q. Is there any reward for people who invite friends? 

R. Currently, no specific reward is defined.

Q. Is the invitation made through a QR code or a link? 

R. It can be either.

Q. Can I register more than one vehicle on my account? 

R. Yes.

Q. Can the same car be in two different accounts? 

R. Yes, in these cases, there should be a mechanism at the parking lot entrance that allows the user to choose from which account the payment will be made (Less of a priority as it corresponds to a very small niche in our business).

Q. Are there specific criteria for adding to the Parky wallet? 

R. Yes.

Q. Can a park manager be associated with more than one park? 

R. Yes.

Q. Do parks have opening and closing hours? 

R. Yes.

Q. What are the responsibilities of the admin? 

R. To create parks, managers, and associate parks with managers.

Q. Is there a park without a manager? 

R. Yes, but it is inactive.

Q. How is the customer rank defined? 

R. The customer rank has three levels and aims to identify the customers who spend the most money in the parks:
   A - Top 20%
   B - Next 60%
   C - Remaining 20%

Q. What criteria should be presented for reports and analysis? 

R. Present only 1 or 2 metrics (total coin value per park, total coin value per vehicle, etc.).

Q. Should the application send individual or group messages? 

R. Individual messages are a priority, but it should also be possible to send messages to a group of people, for example, to communicate promotions.

Q. What information should the admin display regarding the park manager? 

R. Username, Email, Password, Name, Employee Record (When and In which park they have worked before…).