## Meeting 4 ##

Q: What is needed to deliver in the first sprint?

R: In the first sprint, the primary focus is to establish the high-level overview of the project, involving stakeholders, general workflow, and the product backlog. This includes defining epics, prioritizing them using the MOSCOW method, and setting up the sprint backlog, emphasizing top priorities with detailed acceptance criteria, requirements, and the INVEST approach to define user stories.

Q: What value does the application bring to customers? What unique experience does the app offer?

R:  The product vision articulates the value the application brings to customers and the distinct experience it offers. During the project kick-off with the development team, a clear understanding of the product vision is crucial. 

Q: How is the distribution of Parky coins managed?

R: Parky coins are primarily allocated by the system based on predefined limits set by park managers. Client managers can also allocate Parky coins as bonuses to users. 

Q: What happen's if a customer is registed but his car isn't, when accessing to a park?

R: Regarding user access to parking, if a customer is registered but their car isn't, they can update their account by adding the new vehicle's license plate. 

Q: Blocking a customer applies universally across all parking areas?

R: Yes. 

Q: What type of users can have access to the backoffice?

R: The back-office system includes different user types: park managers and client managers. However, customers might request access to information exclusive to these user types.

Q: Is there a rule that defines what it is a nearby park?

R: Determining nearby parking lots is based on geographical proximity and may vary depending on the user's location within the city. For example, if we are in the centre of the city, the distance to define the nearby parks is more small.

Q: What type of filter do we need to have in the dashboard?

R: Filtering by parking lot, month, vehicle type, and total parked minutes.

Q: Can we have the same vehicle registered in many accounts?

R: Yes, but it will not be prioritized

Q: What is needed to register a new employee? And a new manager?

R: Employe/manager number and employee/manager records.

Q: Can I costumer change his vehicle in the app?

R: Yes.

Q: What do we consider as 'nearby'? 

R: It is what's close to us, where I can park.

Q: Does the radius vary according to how many parks are nearby?

R: Not necessarily. The software zooms in until a park appears. There isn't a fixed limit, rather it's based on which parks are closest.

Q: Are there specific priorities or functionalities at the forefront of the project?

R: The current priority revolves around the end-user application. This includes the ability to enter, pay, and exit the parking facility. Initially, the phase does not mandate a map but rather a listing of parking areas. Prioritization regarding back-office functionalities is contingent upon discussions with the client and can be tailored according to the most critical requirements identified from the document.
