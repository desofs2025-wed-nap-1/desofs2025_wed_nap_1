## Meeting 2 ##

Q: What's the primary objective of the application in managing parking locations?

R: The primary focus of the application is to manage and showcase vital information related to parking locations. This encompasses details about the facility's location, capacity, and real-time availability status. The goal is to assist users in locating available parking spaces.

Q: What's the priority between database management and user experience?

R: The application prioritizes providing a seamless and user-friendly experience for customers over intricate database management. The database structure should efficiently handle user accounts and transaction records.

Q: What pricing model is initially considered and what's planned for the second phase?

R: Initially, the application will adopt a straightforward fixed pricing model, like charging 10 cents per minute. In the second phase, the system is aimed at accommodating highly customizable pricing structures.

Q: How do customers earn rewards within the application?

R: Customers earn one point for every hour they spend in a parking facility.

Q: What technical aspects are essential for managing the software development process?

R: Version control and automated builds are crucial for managing the software development process. Cloud deployment is optional.

Q: What should be displayed at the entrance of parking facilities?

R: The entrance displays should offer real-time information regarding the park's status. This includes indicating if a park is full or showing availability when parking spaces are open.

Q: What feature is essential in the application's map function?

R: The application should include a geographical map displaying parking locations and their availability.

Q: What should be ensured while simulating a partnership with SIBS/Mbway?

R: Personal and credit card information must be handled in compliance with relevant data protection regulations.

Q: What's the standard functionality concerning user accounts?

R: Allowing users to delete their accounts is standard. However, the system should prevent users from deleting accounts while they are still inside a parking facility to avoid data discrepancies.

Q: What's the initial focus concerning license plates?

R: Initially, the application should primarily support national license plates. This involves validation, recognition, and handling of license plate information as per the country's specific format and regulations.

Q: What's an expected function regarding user preferences?

R: Predicting user preferences is essential. For instance, the application should learn user habits and suggest more relevant parking options based on this learned behavior.

Q: What analysis is crucial for the application?

R: Conducting a comparative analysis of competing applications.

Q: What are the initial steps in studying the project's requirements?

R: The initial steps involve studying project requirements and technologies. This includes defining team roles, setting project timelines, establishing clear test cases, and overseeing both frontend and backend development.

Q: What does the barrier software simulation involve?

R: The barrier software simulation focuses on creating a system to manage parking barriers effectively. It includes simulating the barrier's open/close timing, a frontend interface for manual control, and an API for interaction within the system.

Q: What's the goal of the license plate recognition software simulation?

R: The objective is to accurately read license plates and relay the data to the central system. It should include a RESTful API for communication and a frontend component for actual plate reading.

Q: What information is provided at the entrance through the component?

R: This component offers real-time information at the entrance, displaying the current status of the parking facility,whether it's available or at full capacity.

Q: What's crucial for ensuring the project's success?

R: Ensuring the project's success relies on team members being flexible to take on multiple roles as needed.