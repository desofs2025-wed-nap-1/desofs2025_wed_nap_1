## Meeting 1 ##

Q What does overseeing the entry and exit points of the parking facility entail?

R Overseeing the entry and exit points involves managing the operational aspects of these locations within the parking facility.

Q How do you ensure controlled access to the facility?

R Implementing security measures to regulate who can enter and exit, typically through a monitoring system.

Q How do drivers receive information about parking space availability?

R Informing drivers about parking space availability through signs displaying messages such as "Parking Full" or "Spaces Available."

Q How is the payment process managed for parking services?

R Managing the payment process involves handling various payment methods like credit cards, mobile apps, etc., for parking services.

Q What's involved in managing multiple parking facilities?

R Need to take in account that each park has its unique characteristics and operational requirements.

Q One park can have more than one floor?

R Yes. Parks can have multiple levels or floors within their structure.

Q How are different vehicle types accommodated within the parking facilities?

R Each park must be organized to accommodate various vehicle types with designated areas for each.

Q What methods are used for controlling access to the parking facility?

R Implementing control measures using barriers and optical license plate readers at the entry and exit points.

Q Who is permitted to enter the parking facility?

R Only registered app users are allowed entry into the parking facility.

Q What service is offered for electric vehicles?

R Providing and managing access to charging stations for electric vehicles.

Q How are GPL vehicles managed within the facility?

R Parks should have suitable parking spaces.

Q What is the approach to pricing based on parking duration?

R Offering flexible pricing structures depending on the time a vehicle spends in the parking facility.

Q How is pricing varied within different areas of the parking facility?

R Implementing pricing variations based on different zones within the parking facility.

Q How is access managed based on specific criteria?

R Managing access to the parking facility based on accounting or contractual criteria, such as barring entry for users with overdue payments or account issues.

Q What system is in place to alert management of payment issues?

R Implementing a system to alert management when users fail to fulfill their payment obligations.

Q Are subscription plans offered to users?

R Offering monthly subscription plans that provide certain benefits or discounts, although it's important to note that a subscription does not guarantee a parking space.

Q What criteria define the vehicles that the facility can accommodate?

R Defining the criteria for vehicle height and width that the parking facility can accommodate.

Q Is pricing variable based on vehicle type?

R Varying pricing for parking based on the type of vehicle, such as motorcycles having different rates than cars.

Q What technology is used for entry/exit control and billing purposes?

R Developing or implementing software that automatically reads and recognizes license plates for control and billing within the facility.