export interface IMovement {
  amount: number;
  date: Date;
  movementType: string;
}
