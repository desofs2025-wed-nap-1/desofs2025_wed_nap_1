export interface IRegisterUserRequest {
  name: string;
  password: string;
  email: string;
  username: string;
}
