export interface IParkingSpotsCount {
  motocycleCount: number;
  gplCount: number;
  electricCount: number;
  automobileCount: number;
}
