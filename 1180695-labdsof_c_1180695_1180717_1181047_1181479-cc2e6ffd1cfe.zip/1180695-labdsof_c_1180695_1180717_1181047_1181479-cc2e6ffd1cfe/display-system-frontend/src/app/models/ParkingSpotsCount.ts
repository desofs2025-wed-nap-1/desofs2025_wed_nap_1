export interface ParkingSpotsCount {
  motocycleCount: number;
  gplCount: number;
  electricCount: number;
  automobileCount: number;
}
