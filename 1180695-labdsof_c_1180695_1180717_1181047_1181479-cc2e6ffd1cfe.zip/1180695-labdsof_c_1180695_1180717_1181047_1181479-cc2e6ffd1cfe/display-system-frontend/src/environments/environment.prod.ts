export const environment = {
  production: false,
  apiURL: 'http://localhost:5000',
  signalRBaseUrl: 'http://localhost:6003',
};
