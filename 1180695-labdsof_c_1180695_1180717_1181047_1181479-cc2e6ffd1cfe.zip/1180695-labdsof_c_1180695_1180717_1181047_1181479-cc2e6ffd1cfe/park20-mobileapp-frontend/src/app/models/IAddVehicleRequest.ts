export interface IAddVehicleRequest {
  licensePlate: string;
  brand: string;
  model: string;
  type: string;
  username: string;
}
