export interface IPaymentMethod {
  lastFourDigits: number;
  fullName: string;
}
