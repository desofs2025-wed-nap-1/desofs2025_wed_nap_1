export interface IPark {
  parkName: string;
  latitude: number;
  longitude: number;
  distanceToTarget: number;
}
