export interface IVehicle {
  licensePlate: string;
  type: string;
  brand: string;
  model: string;
}
