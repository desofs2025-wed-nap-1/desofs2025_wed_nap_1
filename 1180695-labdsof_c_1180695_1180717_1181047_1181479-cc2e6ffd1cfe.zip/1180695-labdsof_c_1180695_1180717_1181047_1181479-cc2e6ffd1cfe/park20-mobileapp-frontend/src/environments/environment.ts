export const environment = {
  production: false,
  apiURL: 'http://localhost:5000',
  apiPaymentService: 'http://localhost:5004',
};
