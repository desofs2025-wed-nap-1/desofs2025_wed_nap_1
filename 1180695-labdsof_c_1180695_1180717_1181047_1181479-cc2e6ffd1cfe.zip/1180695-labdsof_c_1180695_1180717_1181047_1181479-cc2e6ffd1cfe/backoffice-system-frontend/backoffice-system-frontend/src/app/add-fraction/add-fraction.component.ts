import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IFraction } from '../models/IFraction';

@Component({
  selector: 'app-add-fraction',
  templateUrl: './add-fraction.component.html',
  styleUrl: './add-fraction.component.css',
})
export class AddFractionComponent implements OnInit {
  period: any;
  order: number = 0;
  minutes: number = 0;
  automobilePrice: number = 0;
  motorcyclePrice: number = 0;
  gplPrice: number = 0;
  electricPrice: number = 0;

  constructor(
    public ref: DynamicDialogRef,
    private dialogConfig: DynamicDialogConfig
  ) {}

  ngOnInit(): void {
    this.period = this.dialogConfig.data;
  }

  closeDialog() {
    var fraction: IFraction = {
      order: this.order,
      minutes: this.minutes,
      automobilePrice: this.automobilePrice,
      motorcyclePrice: this.motorcyclePrice,
      gplPrice: this.gplPrice,
      electricPrice: this.electricPrice,
    };
    console.log('passed this fraction:');
    console.log(fraction);
    this.ref.close(fraction);
  }
}
