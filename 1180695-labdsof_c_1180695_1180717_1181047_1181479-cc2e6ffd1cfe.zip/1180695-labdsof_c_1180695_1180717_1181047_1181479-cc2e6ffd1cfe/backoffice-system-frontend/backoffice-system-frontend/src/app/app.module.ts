import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MessageService } from 'primeng/api';
import { AppRoutingModule } from './app-routing.module';
import { CardModule } from 'primeng/card';
import { LoginComponent } from './components/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';
import { MenubarModule } from 'primeng/menubar';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { ToolbarModule } from 'primeng/toolbar';
import { AccordionModule } from 'primeng/accordion';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { ToastModule } from 'primeng/toast';
import { HttpClientModule } from '@angular/common/http';
import { MessagesModule } from 'primeng/messages';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputMaskModule } from 'primeng/inputmask';
import { MenuBarComponent } from './components/menu-bar/menu-bar.component';
import { ParkingSpotManagementComponent } from './components/parking-spot-management/parking-spot-management.component';
import { DropdownModule } from 'primeng/dropdown';
import { ChartModule } from 'primeng/chart';
import { PriceTableManagementComponent } from './components/price-table-management/price-table-management.component';
import { ParkyCoinsManagementComponent } from './components/parky-coins-management/parky-coins-management.component';
import { ReportingComponent } from './components/reporting/reporting.component';
import { CalendarModule } from 'primeng/calendar';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { ParkyCoinsBulkAssignComponent } from './components/parky-coins-bulk-assign/parky-coins-bulk-assign.component';
import { AddFractionComponent } from './add-fraction/add-fraction.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

const maskConfig: Partial<IConfig> = {
  validation: true,
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuBarComponent,
    ParkingSpotManagementComponent,
    PriceTableManagementComponent,
    ParkyCoinsManagementComponent,
    ReportingComponent,
    ParkyCoinsBulkAssignComponent,
    AddFractionComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    ConfirmDialogModule,
    CardModule,
    FormsModule,
    InputTextModule,
    ButtonModule,
    PasswordModule,
    MenubarModule,
    TableModule,
    TabMenuModule,
    AvatarGroupModule,
    AvatarModule,
    ToolbarModule,
    AccordionModule,
    RadioButtonModule,
    DynamicDialogModule,
    ToastModule,
    HttpClientModule,
    MessagesModule,
    InputNumberModule,
    InputMaskModule,
    CommonModule,
    FormsModule,
    CardModule,
    DropdownModule,
    ChartModule,
    CalendarModule,
    NgxMaskModule.forRoot(maskConfig),
  ],
  providers: [MessageService],
  bootstrap: [AppComponent],
})
export class AppModule {}
