import { IUpdatePriceTableLine } from './IUpdatePriceTableLine';

export interface IUpdatePriceTable {
  parkName: string;
  nightFee: number;
  initialDate: Date;
  priceLines: IUpdatePriceTableLine[];
}
