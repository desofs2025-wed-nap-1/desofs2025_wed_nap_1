export interface IVehicleOption {
  label: string;
  value: string | undefined;
}
