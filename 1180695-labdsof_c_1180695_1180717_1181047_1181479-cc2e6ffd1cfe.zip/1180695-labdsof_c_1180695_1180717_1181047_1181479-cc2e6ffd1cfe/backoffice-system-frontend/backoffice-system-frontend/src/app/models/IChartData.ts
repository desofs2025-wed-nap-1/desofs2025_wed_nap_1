export interface ChartData {
  username: string;
  parkyCoinsSpent: number;
}
