export interface IUpdateFraction {
  order: number;
  minutes: number;
  vehicleType: number;
  price: number;
}
