import { IUpdatePeriod } from './IUpdatePeriod';

export interface IUpdatePriceTableLine {
  period: IUpdatePeriod;
}
