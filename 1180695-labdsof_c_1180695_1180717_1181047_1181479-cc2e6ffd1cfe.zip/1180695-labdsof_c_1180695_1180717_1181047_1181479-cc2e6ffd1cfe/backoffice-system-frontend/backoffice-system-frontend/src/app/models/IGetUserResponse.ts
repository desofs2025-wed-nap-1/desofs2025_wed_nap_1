export interface IGetUSerResponse {
  username: string;
  email: string;
  name: string;
}
