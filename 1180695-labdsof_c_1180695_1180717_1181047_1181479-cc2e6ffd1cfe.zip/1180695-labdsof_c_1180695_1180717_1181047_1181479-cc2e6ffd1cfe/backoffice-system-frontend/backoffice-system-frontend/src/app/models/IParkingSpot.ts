import { VehicleType } from './IVehicleType';

export interface IParkingSpot {
  id: number;
  status: boolean; // 1 para ligado, 0 para desligado
  type: VehicleType;
}
