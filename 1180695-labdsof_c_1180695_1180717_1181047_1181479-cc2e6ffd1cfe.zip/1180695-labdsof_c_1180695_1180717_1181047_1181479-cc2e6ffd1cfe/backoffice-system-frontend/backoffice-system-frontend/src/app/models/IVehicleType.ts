export enum VehicleType {
  Motorcycle = 0,
  Automobile = 1,
  GPL = 2,
  Electric = 3,
}
