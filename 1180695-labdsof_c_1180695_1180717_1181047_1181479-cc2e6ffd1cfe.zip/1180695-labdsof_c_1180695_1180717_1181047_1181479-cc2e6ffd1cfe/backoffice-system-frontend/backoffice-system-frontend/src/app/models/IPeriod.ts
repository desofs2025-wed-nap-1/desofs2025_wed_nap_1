import { Time } from '@angular/common';
import { IFraction } from './IFraction';

export interface IPeriod {
  initialTime: string;
  finalTime: string;
  fractionList: IFraction[];
}
