import { IUpdateFraction } from './IUpdateFraction';

export interface IUpdatePeriod {
  initialTime: string;
  finalTime: string;
  fractionList: IUpdateFraction[];
}
