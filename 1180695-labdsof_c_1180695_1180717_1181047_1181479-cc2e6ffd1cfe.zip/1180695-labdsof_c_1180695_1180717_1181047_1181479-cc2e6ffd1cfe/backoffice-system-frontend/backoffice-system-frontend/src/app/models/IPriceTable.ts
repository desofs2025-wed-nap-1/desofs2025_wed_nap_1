import { IPriceTableLine } from './IPriceTableLine';

export interface IPriceTable {
  parkName: string;
  nightFee: number;
  initialDate: Date;
  priceLines: IPriceTableLine[];
}
