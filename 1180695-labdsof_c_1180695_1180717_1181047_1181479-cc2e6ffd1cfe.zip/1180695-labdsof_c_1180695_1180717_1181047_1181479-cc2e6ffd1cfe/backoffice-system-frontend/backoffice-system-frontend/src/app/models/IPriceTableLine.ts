import { IPeriod } from './IPeriod';

export interface IPriceTableLine {
  period: IPeriod;
}
