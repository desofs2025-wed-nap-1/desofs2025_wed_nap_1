export interface IFraction {
  order: number;
  minutes: number;
  automobilePrice: number;
  motorcyclePrice: number;
  gplPrice: number;
  electricPrice: number;
}
