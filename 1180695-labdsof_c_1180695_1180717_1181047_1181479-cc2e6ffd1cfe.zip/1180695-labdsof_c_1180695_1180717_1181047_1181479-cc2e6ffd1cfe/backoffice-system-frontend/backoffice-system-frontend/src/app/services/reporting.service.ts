import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ChartData } from '../models/IChartData';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ReportingService {
  constructor(private http: HttpClient) {}

  getWorstChartData(
    parkName?: string,
    initialDate?: Date,
    endDate?: Date,
    vehicleType?: string,
  ): Observable<any> {
    const url = this.buildUrl(
      'Worst',
      parkName,
      initialDate,
      endDate,
      vehicleType
    );
    return this.http.get(url);
  }

  getMidChartData(
    parkName?: string,
    initialDate?: Date,
    endDate?: Date,
    vehicleType?: string
  ): Observable<any> {
    const url = this.buildUrl(
      'Mid',
      parkName,
      initialDate,
      endDate,
      vehicleType
    );
    return this.http.get(url);
  }

  getBestChartData(
    parkName?: string,
    initialDate?: Date,
    endDate?: Date,
    vehicleType?: string,
  ): Observable<any> {
    const url = this.buildUrl(
      'Best',
      parkName,
      initialDate,
      endDate,
      vehicleType
    );
    return this.http.get(url);
  }

  private buildUrl(
    endpoint: string,
    parkName?: string,
    initialDate?: Date,
    endDate?: Date,
    vehicleType?: string,
  ): string {
    const baseurl =
      environment.apiURL + `/api/Dashboard/DashBoard${endpoint}Users`;

    const params = [];

    if (parkName !== undefined) {
      params.push(`parkName=${encodeURIComponent(parkName)}`);
    }

    if (initialDate !== undefined) {
      params.push(`initialDate=${initialDate.toISOString().split('T')[0]}`);
    }

    if (endDate !== undefined) {
      params.push(`endDate=${endDate.toISOString().split('T')[0]}`);
    }

    if (vehicleType !== undefined) {
      params.push(`vehicleType=${vehicleType}`);
    }

    if (params.length > 0) {
      return `${baseurl}?${params.join('&')}`;
    }

    return baseurl;
  }
}
