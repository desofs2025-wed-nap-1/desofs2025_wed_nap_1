import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { IPriceTable } from '../models/IPriceTable';
import { IUpdatePriceTable } from '../models/IUpdatePriceTable';

@Injectable({
  providedIn: 'root',
})
export class ParkService {
  constructor(private http: HttpClient) {}

  getParkNames(): Observable<any> {
    const url = environment.apiURL + '/api/Park/GetParkNames';
    return this.http.get(url);
  }

  getParkingSpots(parkName: string): Observable<any> {
    const url =
      environment.apiURL + '/api/Park/GetParkingSpots?parkName=' + parkName;
    return this.http.get(url);
  }

  getUpdateParkingSpots(
    parkingSpotId: number,
    status: boolean
  ): Observable<any> {
    const url = environment.apiURL + '/api/Park/UpdateParkingSpotStatus';
    const body = { status: status, parkingSpotId: parkingSpotId };
    return this.http.put(url, body);
  }

  getPriceTableByParkName(parkName: string): Observable<any> {
    const url =
      environment.apiURL +
      '/api/Park/GetPriceTableByParkName?parkName=' +
      parkName;
    return this.http.get(url);
  }

  updatePriceTable(updateRequest: IUpdatePriceTable): Observable<any> {
    const url = environment.apiURL + '/api/Park/UpdatePriceTable';
    return this.http.post(url, updateRequest);
  }
}
