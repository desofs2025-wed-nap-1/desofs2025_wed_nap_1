import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ParkyCoinService {
  constructor(private http: HttpClient) {}

  getActualParkingPerHourValue(): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/ParkingPerHourValue';
    return this.http.get(url);
  }

  getActualRegistryValue(): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/RegistryValue';
    return this.http.get(url);
  }

  getBulkValue(): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/BulkValue';
    return this.http.get(url);
  }

  updateParkingPerHourValue(amount: number): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/Parking';
    return this.http.patch(url, amount);
  }

  updateRegistryValue(amount: number): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/NewCustomer';
    return this.http.patch(url, amount);
  }

  updateBulkValue(amount: number): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/Bulk';
    return this.http.patch(url, amount);
  }

  bulkAssign(usernames: string[]): Observable<any> {
    const url = environment.apiURL + '/api/ParkyWallet/BulkAssign';
    return this.http.post(url, usernames);
  }
}
