import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkyCoinsBulkAssignComponent } from './parky-coins-bulk-assign.component';

describe('ParkyCoinsBulkAssignComponent', () => {
  let component: ParkyCoinsBulkAssignComponent;
  let fixture: ComponentFixture<ParkyCoinsBulkAssignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParkyCoinsBulkAssignComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParkyCoinsBulkAssignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
