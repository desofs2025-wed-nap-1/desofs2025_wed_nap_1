import { Component, OnInit } from '@angular/core';
import { IGetUSerResponse } from '../../models/IGetUserResponse';
import { UserService } from '../../services/user.service';
import { ParkyCoinService } from '../../services/parky-coins.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-parky-coins-bulk-assign',
  templateUrl: './parky-coins-bulk-assign.component.html',
  styleUrl: './parky-coins-bulk-assign.component.css',
})
export class ParkyCoinsBulkAssignComponent implements OnInit {
  users: IGetUSerResponse[] = [];
  selectedUsers: IGetUSerResponse[] = [];

  valueBulk: number = 0;

  constructor(
    private userService: UserService,
    private parkyCoinsService: ParkyCoinService,
    private messageService: MessageService
  ) {}
  ngOnInit(): void {
    this.userService.getUsers().subscribe(
      (response: IGetUSerResponse[]) => {
        this.users = response;
      },
      (error) => {
        console.error('Erro ao obter usuários:', error);
      }
    );
    this.parkyCoinsService.getBulkValue().subscribe((response) => {
      this.valueBulk = response;
    });
  }

  bulkAssign() {
    var usernames: string[] = [];
    this.selectedUsers.forEach((user) => {
      usernames.push(user.username);
    });
    this.parkyCoinsService.bulkAssign(usernames).subscribe((response) => {
      if (response == true) {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          sticky: true,
          detail: 'Parky Coins Successfully Assigned.',
        });
      }
    });
  }
}
