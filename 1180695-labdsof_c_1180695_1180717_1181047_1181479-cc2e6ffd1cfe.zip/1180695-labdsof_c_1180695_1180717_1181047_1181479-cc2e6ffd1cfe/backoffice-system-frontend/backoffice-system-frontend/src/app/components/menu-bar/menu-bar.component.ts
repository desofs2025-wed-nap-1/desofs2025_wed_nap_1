import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css'],
})
export class MenuBarComponent {
  items: any[];

  constructor(private router: Router) {
    this.items = [
      {
        label: 'Reporting',
        icon: 'pi pi-fw pi-chart-bar',
        command: () => this.router.navigate(['/reporting']),
      },
      {
        label: 'Park Management',
        icon: 'pi pi-fw pi-car',
        items: [
          {
            label: 'Parking Spot Management',
            icon: 'pi pi-fw pi-cog',
            command: () => this.router.navigate(['/parking-spot-management']),
          },
          {
            label: 'Price Table Management',
            icon: 'pi pi-fw pi-euro',
            command: () => this.router.navigate(['/price-table-management']),
          },
        ],
      },
      {
        label: 'Parky Coins Management',
        icon: 'pi pi-fw pi-money-bill',
        items: [
          {
            label: 'Configure Parky Coins',
            icon: 'pi pi-fw pi-cog',
            command: () => this.router.navigate(['/parky-coin-management']),
          },
          {
            label: 'Bulk Parky Coins Assign',
            icon: 'pi pi-fw pi-users',
            command: () => this.router.navigate(['/bulk-assign']),
          },
        ],
      },
    ];
  }
}
