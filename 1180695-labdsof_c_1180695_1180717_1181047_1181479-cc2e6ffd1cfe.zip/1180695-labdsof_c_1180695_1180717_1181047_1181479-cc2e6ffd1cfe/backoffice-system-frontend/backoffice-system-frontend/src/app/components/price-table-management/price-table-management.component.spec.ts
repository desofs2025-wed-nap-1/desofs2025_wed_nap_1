import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PriceTableManagementComponent } from './price-table-management.component';

describe('PriceTableManagementComponent', () => {
  let component: PriceTableManagementComponent;
  let fixture: ComponentFixture<PriceTableManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PriceTableManagementComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PriceTableManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
