import { Component } from '@angular/core';
import { ParkService } from '../../services/park.service';
import { IPriceTableLine } from '../../models/IPriceTableLine';
import { IUpdatePriceTable } from '../../models/IUpdatePriceTable';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { AddFractionComponent } from '../../add-fraction/add-fraction.component';
import { IPeriod } from '../../models/IPeriod';
import { ConfirmationService, MessageService } from 'primeng/api';
import { IFraction } from '../../models/IFraction';
import { IUpdateFraction } from '../../models/IUpdateFraction';
import { IPriceTable } from '../../models/IPriceTable';
import { IUpdatePeriod } from '../../models/IUpdatePeriod';
import { IUpdatePriceTableLine } from '../../models/IUpdatePriceTableLine';

@Component({
  selector: 'app-price-table-management',
  templateUrl: './price-table-management.component.html',
  styleUrl: './price-table-management.component.css',
  providers: [ConfirmationService, DialogService],
})
export class PriceTableManagementComponent {
  ref: DynamicDialogRef | undefined;
  priceTableLines: IPriceTableLine[] = [];
  priceTable: any;
  initialTime: string = '';
  finalTime: string = '';
  parkList: string[] = [];
  nightFee: number = 0;
  initialDate: any;
  selectedPark: string = '';
  constructor(
    private parkService: ParkService,
    public dialogService: DialogService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit(): void {
    this.parkService.getParkNames().subscribe((result: any) => {
      this.parkList = result;
    });
  }

  getOrderedNumberSuffix(num: number): string {
    if (num >= 11 && num <= 13) {
      return num + 'th';
    }
    switch (num % 10) {
      case 1:
        return num + 'st';
      case 2:
        return num + 'nd';
      case 3:
        return num + 'rd';
      default:
        return num + 'th';
    }
  }

  getPriceTable() {
    if (this.selectedPark) {
      this.parkService
        .getPriceTableByParkName(this.selectedPark)
        .subscribe((result: IPriceTable) => {
          this.priceTable = result;
          this.priceTableLines = result.priceLines;
          this.nightFee = result.nightFee;
          this.initialDate = result.initialDate;
        });
    }
  }

  updatePriceTable(updatedPriceTable: IUpdatePriceTable) {
    this.parkService
      .updatePriceTable(updatedPriceTable)
      .subscribe((result: any) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Updated Price Table',
        });
        this.getPriceTable();
      });
  }

  addFractionToPeriod(period: IPeriod) {
    this.ref = this.dialogService.open(AddFractionComponent, {
      header: 'Add New Fraction',
      data: period,
    });
    this.ref.onClose.subscribe((fraction: IFraction) => {
      if (fraction) {
        var newPriceTable = this.mapPriceTableToPriceTableUpdate(
          this.priceTable
        );
        newPriceTable.priceLines.forEach((line: IUpdatePriceTableLine) => {
          if (
            line.period.initialTime === period.initialTime &&
            line.period.finalTime === period.finalTime
          ) {
            line.period.fractionList = line.period.fractionList.concat(
              this.mapFractionToUpdateFraction(fraction)
            );
          }
        });
        this.updatePriceTable(newPriceTable);
      }
    });
  }

  mapFractionToUpdateFraction(fraction: IFraction): IUpdateFraction[] {
    var updatedFractions: IUpdateFraction[] = [
      {
        order: fraction.order,
        minutes: fraction.minutes,
        vehicleType: 0,
        price: fraction.motorcyclePrice,
      },
      {
        order: fraction.order,
        minutes: fraction.minutes,
        vehicleType: 1,
        price: fraction.automobilePrice,
      },
      {
        order: fraction.order,
        minutes: fraction.minutes,
        vehicleType: 2,
        price: fraction.gplPrice,
      },
      {
        order: fraction.order,
        minutes: fraction.minutes,
        vehicleType: 3,
        price: fraction.electricPrice,
      },
    ];
    return updatedFractions;
  }

  mapPriceTableToPriceTableUpdate(priceTable: IPriceTable): IUpdatePriceTable {
    var priceLinesUpdatedList: IUpdatePriceTableLine[] = [];
    priceTable.priceLines.forEach((line: IPriceTableLine) => {
      var priceLineUpdated: IUpdatePriceTableLine = {
        period: this.mapPeriodToPeriodUpdate(line.period),
      };
      priceLinesUpdatedList.push(priceLineUpdated);
    });
    return {
      parkName: priceTable.parkName,
      nightFee: priceTable.nightFee,
      initialDate: priceTable.initialDate,
      priceLines: priceLinesUpdatedList,
    };
  }

  mapPeriodToPeriodUpdate(period: IPeriod): IUpdatePeriod {
    var fractionUpdatedList: IUpdateFraction[] = [];
    period.fractionList.forEach((fraction: IFraction) => {
      fractionUpdatedList = fractionUpdatedList.concat(
        this.mapFractionToUpdateFraction(fraction)
      );
    });
    return {
      initialTime: period.initialTime,
      finalTime: period.finalTime,
      fractionList: fractionUpdatedList,
    };
  }

  confirm(periodToDelete: IPeriod) {
    this.confirmationService.confirm({
      message: 'Do you want to delete this record?',
      header: 'Delete Confirmation',
      icon: 'pi pi-info-circle',
      acceptButtonStyleClass: 'p-button-danger p-button-text',
      rejectButtonStyleClass: 'p-button-text p-button-text',
      acceptIcon: 'none',
      rejectIcon: 'none',

      accept: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Confirmed',
          detail: 'Record deleted',
        });
        this.deletePeriod(periodToDelete);
      },
      reject: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Rejected',
          detail: 'You have rejected',
        });
      },
    });
  }

  deletePeriod(periodToDelete: IPeriod) {
    var newPriceTable = this.mapPriceTableToPriceTableUpdate(this.priceTable);
    for (let i = 0; i < newPriceTable.priceLines.length; i++) {
      const line = newPriceTable.priceLines[i];
      if (
        line.period.initialTime === periodToDelete.initialTime &&
        line.period.finalTime === periodToDelete.finalTime
      ) {
        // Remove the period from the fractionList
        newPriceTable.priceLines.splice(i, 1);
        break; // Exit the loop since you found and removed the period
      }
    }
    this.updatePriceTable(newPriceTable);
  }

  addPeriod() {
    var newPriceTable = this.mapPriceTableToPriceTableUpdate(this.priceTable);
    var newPeriod: IUpdatePeriod = {
      initialTime: this.initialTime,
      finalTime: this.finalTime,
      fractionList: [],
    };
    var newPriceTableLine: IUpdatePriceTableLine = {
      period: newPeriod,
    };
    newPriceTable.priceLines.push(newPriceTableLine);
    this.updatePriceTable(newPriceTable);
    this.initialTime = '';
    this.finalTime = '';
  }

  createFractionToPeriod(period: IPeriod) {
    this.ref = this.dialogService.open(AddFractionComponent, {
      header: 'Add New Fraction',
      data: period,
    });
    this.ref.onClose.subscribe((fraction: IFraction) => {
      if (fraction) {
        var newPriceTable = this.mapPriceTableToPriceTableUpdate(
          this.priceTable
        );
        newPriceTable.priceLines.forEach((line: IUpdatePriceTableLine) => {
          if (
            line.period.initialTime === period.initialTime &&
            line.period.finalTime === period.finalTime
          ) {
            line.period.fractionList = line.period.fractionList.concat(
              this.mapFractionToUpdateFraction(fraction)
            );
          }
        });
        this.updatePriceTable(newPriceTable);
      }
    });
  }
}
