import { Component, ViewChild } from '@angular/core';
import { ReportingService } from '../../services/reporting.service';
import { ChartData } from '../../models/IChartData';
import * as XLSX from 'xlsx';
import { ParkService } from '../../services/park.service';
import { IOption } from '../../models/IOption';
import { VehicleType } from '../../models/IVehicleType';
import { IVehicleOption } from '../../models/IVehicleOptions';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.css'],
})
export class ReportingComponent {
  @ViewChild('table1', { static: false }) table1: any; // Reference to the first table
  @ViewChild('table2', { static: false }) table2: any; // Reference to the second table
  @ViewChild('table3', { static: false }) table3: any; // Reference to the third table

  bestData: ChartData[] = [];
  worstData: ChartData[] = [];
  midData: ChartData[] = [];

  parkOptions: IOption[] = [];
  vehicleOptions: IVehicleOption[] = [
    { label: 'All', value: undefined },
    { label: 'Motorcycle', value: '0' },
    { label: 'Automobile', value: '1' },
    { label: 'GPL', value: '2' },
    { label: 'Electric', value: '3' },
  ];
  selectedPark: any = undefined;
  selectedVehicleType: any = undefined;
  initialDate: string | undefined;
  finalDate: string | undefined;

  constructor(
    private reportingService: ReportingService,
    private parkService: ParkService
  ) {}

  ngOnInit() {
    this.reportingService
      .getBestChartData()
      .subscribe((chartData: ChartData[]) => {
        this.bestData = chartData.map((item) => {
          return {
            username: item.username,
            parkyCoinsSpent: item.parkyCoinsSpent,
          };
        });
      });
    this.reportingService
      .getMidChartData()
      .subscribe((chartData: ChartData[]) => {
        this.midData = chartData.map((item) => {
          return {
            username: item.username,
            parkyCoinsSpent: item.parkyCoinsSpent,
          };
        });
      });
    this.reportingService
      .getWorstChartData()
      .subscribe((chartData: ChartData[]) => {
        this.worstData = chartData.map((item) => {
          return {
            username: item.username,
            parkyCoinsSpent: item.parkyCoinsSpent,
          };
        });
      });
    this.parkService.getParkNames().subscribe((response) => {
      this.parkOptions = [
        { label: 'All', value: undefined },
        ...response.map((parkName: string) => ({
          label: parkName,
          value: parkName,
        })),
      ];
    });
  }

  exportToExcel() {
    const tables = [this.table1, this.table2, this.table3].filter(
      (table) => !!table
    );

    if (tables.length === 0) {
      console.error('No tables to export');
      return;
    }

    const workbook = XLSX.utils.book_new();

    tables.forEach((table, index) => {
      const sheetName = this.getSheetName(index);
      const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
        table.el.nativeElement
      );
      XLSX.utils.book_append_sheet(workbook, ws, sheetName);
    });

    XLSX.writeFile(workbook, 'exported-data.xlsx');
  }

  private getSheetName(index: number): string {
    switch (index) {
      case 0:
        return 'Top 20% Clients';
      case 1:
        return 'Next 60% Clients';
      case 2:
        return 'Remaining 20% Clients';
      default:
        return `Sheet${index + 1}`;
    }
  }

  filter() {
    const parkName =
      this.selectedPark === 'undefined' ? undefined : this.selectedPark;
    const vehicleType =
      this.selectedVehicleType === 'undefined'
        ? undefined
        : this.selectedVehicleType;

    console.log(this.initialDate);

    this.reportingService
      .getBestChartData(
        parkName,
        this.createDateFromDDMMYYYY(this.initialDate),
        this.createDateFromDDMMYYYY(this.finalDate),
        vehicleType
      )
      .subscribe((chartData: ChartData[]) => {
        this.bestData = chartData.map((item) => ({
          username: item.username,
          parkyCoinsSpent: item.parkyCoinsSpent,
        }));
      });

    this.reportingService
      .getMidChartData(
        parkName,
        this.createDateFromDDMMYYYY(this.initialDate),
        this.createDateFromDDMMYYYY(this.finalDate),
        vehicleType
      )
      .subscribe((chartData: ChartData[]) => {
        this.midData = chartData.map((item) => ({
          username: item.username,
          parkyCoinsSpent: item.parkyCoinsSpent,
        }));
      });

    this.reportingService
      .getWorstChartData(
        parkName,
        this.createDateFromDDMMYYYY(this.initialDate),
        this.createDateFromDDMMYYYY(this.finalDate),
        vehicleType
      )
      .subscribe((chartData: ChartData[]) => {
        this.worstData = chartData.map((item) => ({
          username: item.username,
          parkyCoinsSpent: item.parkyCoinsSpent,
        }));
      });
  }

  createDateFromDDMMYYYY(dateString: string | undefined) {
    if (dateString === undefined || dateString === '') {
      return undefined;
    }
    const day = parseInt(dateString!.substring(0, 2), 10);
    const month = parseInt(dateString!.substring(2, 4), 10) - 1;
    const year = parseInt(dateString!.substring(4, 8), 10);

    const date = new Date(year, month, day);

    return date;
  }
}
