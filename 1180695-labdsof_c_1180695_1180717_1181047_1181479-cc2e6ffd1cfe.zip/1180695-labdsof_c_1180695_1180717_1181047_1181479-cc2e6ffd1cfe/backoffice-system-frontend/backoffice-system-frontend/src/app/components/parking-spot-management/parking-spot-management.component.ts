import { Component, OnInit } from '@angular/core';
import { ParkService } from '../../services/park.service';
import { IParkingSpot } from '../../models/IParkingSpot';
import { IOption } from '../../models/IOption';
import { VehicleType } from '../../models/IVehicleType';

@Component({
  selector: 'app-parking-spot-management',
  templateUrl: './parking-spot-management.component.html',
  styleUrls: ['./parking-spot-management.component.css'],
})
export class ParkingSpotManagementComponent implements OnInit {
  selectedPark: string = '';
  searchPerformed: boolean = false;

  parkOptions: IOption[] = [];

  parkingSpots: IParkingSpot[] = [];

  constructor(private parkService: ParkService) {}
  ngOnInit(): void {
    this.getParkNames();
  }

  onSubmit() {
    this.getParkingSpots();
    this.searchPerformed = true;
  }

  onButtonClick(parkingSpot: IParkingSpot): void {
    parkingSpot.status = parkingSpot.status === true ? false : true;

    this.parkService
      .getUpdateParkingSpots(parkingSpot.id, !parkingSpot.status)
      .subscribe();
  }
  parkingSpotsByType(type: VehicleType): IParkingSpot[] {
    return this.parkingSpots.filter((spot) => spot.type === type);
  }

  getVehicleTypeLabel(type: VehicleType): string {
    switch (type) {
      case VehicleType.Motorcycle:
        return 'Motorcycle';
      case VehicleType.Automobile:
        return 'Automobile';
      case VehicleType.GPL:
        return 'GPL';
      case VehicleType.Electric:
        return 'Electric';
      default:
        return '';
    }
  }
  getVehicleTypes(): number[] {
    return Object.values(VehicleType) as number[];
  }

  getParkNames() {
    this.parkService.getParkNames().subscribe((response) => {
      this.parkOptions = response.map((parkName: string) => ({
        label: parkName,
        value: parkName,
      }));
    });
  }

  getParkingSpots() {
    this.parkService
      .getParkingSpots(this.selectedPark)
      .subscribe((response) => {
        this.parkingSpots = response.map((spot: any) => ({
          id: spot.parkingSpotId,
          status: spot.status ? false : true,
          type: spot.vehicleType,
        }));
      });
  }
}
