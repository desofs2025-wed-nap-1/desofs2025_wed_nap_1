import { Component, OnInit } from '@angular/core';
import { ParkyCoinService } from '../../services/parky-coins.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-parky-coins-management',
  templateUrl: './parky-coins-management.component.html',
  styleUrl: './parky-coins-management.component.css',
})
export class ParkyCoinsManagementComponent implements OnInit {
  actualNumberParking: number = 0;
  actualNumberRegistry: number = 0;
  actualNumberBulk: number = 0;

  newNumberParking: number = 0;
  newNumberRegistry: number = 0;
  newNumberBulk: number = 0;

  constructor(
    private service: ParkyCoinService,
    private messageService: MessageService
  ) {}
  ngOnInit(): void {
    this.service.getActualParkingPerHourValue().subscribe((response) => {
      this.actualNumberParking = response;
    });
    this.service.getActualRegistryValue().subscribe((response) => {
      this.actualNumberRegistry = response;
    });
    this.service.getBulkValue().subscribe((response) => {
      this.actualNumberBulk = response;
    });
  }

  updateRegistryValue() {
    this.service
      .updateRegistryValue(this.newNumberRegistry)
      .subscribe((response) => {
        if (response == true) {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            sticky: true,
            detail:
              'Value successfully updated to ' + this.newNumberRegistry + '.',
          });
          this.actualNumberRegistry = this.newNumberRegistry;
          this.newNumberRegistry = 0;
        }
      });
  }

  updateParkingValue() {
    this.service
      .updateParkingPerHourValue(this.newNumberParking)
      .subscribe((response) => {
        if (response == true) {
          this.actualNumberParking = this.newNumberParking;
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            sticky: true,
            detail:
              'Value successfully updated to ' + this.newNumberParking + '.',
          });
          this.newNumberParking = 0;
        }
      });
  }

  updateBulkValue() {
    this.service.updateBulkValue(this.newNumberBulk).subscribe((response) => {
      if (response == true) {
        this.actualNumberBulk = this.newNumberBulk;
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          sticky: true,
          detail: 'Value successfully updated to ' + this.newNumberBulk + '.',
        });
        this.newNumberBulk = 0;
      }
    });
  }
}
