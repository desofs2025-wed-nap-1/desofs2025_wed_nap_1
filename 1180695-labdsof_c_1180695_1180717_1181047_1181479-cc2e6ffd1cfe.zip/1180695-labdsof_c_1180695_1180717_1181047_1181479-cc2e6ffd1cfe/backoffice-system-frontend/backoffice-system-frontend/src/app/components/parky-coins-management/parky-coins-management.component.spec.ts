import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkyCoinsManagementComponent } from './parky-coins-management.component';

describe('ParkyCoinsManagementComponent', () => {
  let component: ParkyCoinsManagementComponent;
  let fixture: ComponentFixture<ParkyCoinsManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParkyCoinsManagementComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParkyCoinsManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
