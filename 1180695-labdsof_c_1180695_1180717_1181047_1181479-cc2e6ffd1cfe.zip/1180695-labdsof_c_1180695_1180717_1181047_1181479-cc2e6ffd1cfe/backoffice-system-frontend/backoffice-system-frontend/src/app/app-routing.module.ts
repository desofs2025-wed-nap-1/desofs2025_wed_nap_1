import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginComponent } from './components/login/login.component';
import { ParkyCoinsManagementComponent } from './components/parky-coins-management/parky-coins-management.component';
import { ReportingComponent } from './components/reporting/reporting.component';
import { PriceTableManagementComponent } from './components/price-table-management/price-table-management.component';
import { ParkingSpotManagementComponent } from './components/parking-spot-management/parking-spot-management.component';
import { ParkyCoinsBulkAssignComponent } from './components/parky-coins-bulk-assign/parky-coins-bulk-assign.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'parky-coin-management', component: ParkyCoinsManagementComponent },
  { path: 'price-table-management', component: PriceTableManagementComponent },
  {
    path: 'parking-spot-management',
    component: ParkingSpotManagementComponent,
  },
  { path: 'reporting', component: ReportingComponent },
  { path: 'bulk-assign', component: ParkyCoinsBulkAssignComponent },
  { path: '**', redirectTo: '/login' },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
