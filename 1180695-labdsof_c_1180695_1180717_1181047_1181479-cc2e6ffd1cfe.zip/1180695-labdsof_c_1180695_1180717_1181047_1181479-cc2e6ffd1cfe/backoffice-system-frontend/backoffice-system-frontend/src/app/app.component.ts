import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], // Correção: use "styleUrls" em vez de "styleUrl"
})
export class AppComponent {
  constructor(public router: Router) {}

  isLoginRoute() {
    return this.router.url === '/login';
  }
}
